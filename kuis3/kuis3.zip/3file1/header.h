/*
Saya ilham akbar[2201017] mengerjakan soal
kuis 3 dalam mata kuliah algoritma dan pemrograman 1
untuk keberkahanNya maka saya
tidak melakukan kecurangan seperti yang telah dispesifikasikan. Aamiin.
*/

#include <stdio.h>
// umtuk menampung ke tiga masukan 
typedef struct{
    int masukan1,masukan2,masukan3;
}balok;
// dekralasi fumgsi untuk menghitung nilai terpanjang 
int menghitung(balok p[100],int terpanjang, int j);