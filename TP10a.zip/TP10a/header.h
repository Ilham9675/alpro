#include <stdio.h>
#include <string.h>

void hasil(int syarat1, int syarat2);
int move(int wadah,int pindah);