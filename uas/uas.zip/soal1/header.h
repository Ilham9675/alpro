/*
Saya ilham akbar[2201017] mengerjakan soal
uas dalam mata kuliah algoritma dan pemrograman 1
untuk keberkahanNya maka saya
tidak melakukan kecurangan seperti yang telah dispesifikasikan. Aamiin.
*/
#include <stdio.h>
#include <string.h>

void pengeluaran(int pengulangan, char kata1, char kata2, char kata3);
int pengecekanvokal(char kata,int cek);
int pengecekankonsonan(char kata,int cek);