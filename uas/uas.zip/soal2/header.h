/*
Saya ilham akbar[2201017] mengerjakan soal
uas dalam mata kuliah algoritma dan pemrograman 1
untuk keberkahanNya maka saya
tidak melakukan kecurangan seperti yang telah dispesifikasikan. Aamiin.
*/
#include <stdio.h>
#include <string.h>

typedef struct{
    int balok[4];// untuk wadah integer yang akan dihitung tenganya
}kotak;
int pengeluaran(int hasil);
void tampilan(int spasi);