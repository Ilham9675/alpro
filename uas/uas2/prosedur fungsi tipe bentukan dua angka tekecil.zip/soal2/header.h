
#include <stdio.h>
#include <string.h>

typedef struct{
    int balok[4];
    int baru[2];
}kotak;
int spasiangka(int hasil);
void tampilan(int spasi);