#include <stdio.h>

void mencari(int baris ,int kolom,int matriks[baris][kolom]);
void mengkali(int baris ,int kolom,int matriks[baris][kolom]);
void transpose(int baris ,int kolom,int matriks[baris][kolom]);
void cermin(int baris ,int kolom,int matriks[baris][kolom]);
void perbandingan(int baris ,int kolom,int matriks[baris][kolom]);