#include <stdio.h>

int pangkat(int n,int m);// fungsi untuk mencari nilai yang si pangkat