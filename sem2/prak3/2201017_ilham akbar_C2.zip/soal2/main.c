#include "header.h"

int main(){

    int n,m;// mausukan pertama untuk nilai dan yang ke dua untuk pangkat
    scanf("%d %d",&n,&m);// masukan dari user
    printf("%d\n",pangkat(n,m));// mencari nilai yang sudah di pangkat

    return 0;
}