#include <stdio.h>

void pola(int n,int m);// mencari sebuah pola