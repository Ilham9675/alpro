#include "header.h"

int main(){

    int n,m;// mauskna nilai satu dan nilai dua
    scanf("%d %d",&n,&m);// meminta masukan dari user
    pola(n,m);// mencari dan menampilkan pola

    return 0;
}