#include <stdio.h>

void kebalik(char n);// untuk membalikan angkat karakter secakebalik