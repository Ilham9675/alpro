#include "header.h"

int main(){

    kebalik(65);// memanggil sebuah prosedur
    return 0;
}