#include <stdio.h>
#include <string.h>
typedef struct{
    char nama[100];// nama 
    int red;// warna merah
    int green;// warna hijau
    int blue;// warna biru
}warna;