#include <stdio.h>
#include <string.h>

void insertion(int jumlah,char kata[jumlah][100]);// untuk menyusun kata dengan menggunkan  insertion
void selection(int jumlah,char kata[jumlah][100]);// untuk menyusun kata dengan menggunkan  insertion
void masukan(int jumlah, char kata[jumlah][100]);// untuk meminta masukan dari user
void tampilan(int jumlah, char kata[jumlah][100]);// untuk menampilkan dari user