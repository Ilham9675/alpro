
#include <stdio.h>
void sequentialsearch(int jumlah, int arr[jumlah],int value[jumlah], int target);
