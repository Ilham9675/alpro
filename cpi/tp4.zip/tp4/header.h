#include <stdio.h>
#include <string.h>
void insertion(int jumlah,char nama[jumlah][100],int nilai[jumlah],char kode[5]);
void selection(int jumlah,char nama[jumlah][100],int nilai[jumlah], char kode[5]);